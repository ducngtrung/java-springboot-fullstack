package org.example;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        Person p = new Person(1, "Ngọc", 26);
    }
}

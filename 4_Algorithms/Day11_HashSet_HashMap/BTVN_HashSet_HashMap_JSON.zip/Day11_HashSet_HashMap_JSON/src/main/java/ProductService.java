import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.lang.reflect.Type;
import java.util.*;

public class ProductService {
    public List<Product> getAllProducts() {
        Gson gson = new Gson();
        List<Product> productList = new ArrayList<>();
        try {
            FileReader readFile = new FileReader("product.json");
            Type objectType = new TypeToken<List<Product>>(){}.getType();
            productList = gson.fromJson(readFile, objectType);
        } catch (FileNotFoundException exception) {
            System.out.println("Không tìm thấy file");
        }
        return productList;
    }

    public void printAllCategories(List<Product> productList) {
        Map<String, Integer> categoryMap = new HashMap<>();
        for (Product product : productList) {
            String[] categoryArray = product.getCategory();
            for (String str : categoryArray) {
                if (!categoryMap.containsKey(str)) {
                    categoryMap.put(str, 1);
                } else {
                    categoryMap.put(str, categoryMap.get(str)+1);
                }
            }
        }
        for (Map.Entry<String, Integer> entry : categoryMap.entrySet()) {
            System.out.println(entry.getKey() + " - " + entry.getValue());
        }
    }
}
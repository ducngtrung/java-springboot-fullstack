import java.util.*;

// Đọc file Json sau https://github.com/EriChannel/Algorithm_12A/blob/main/product.json
// Lấy dữ liệu sản phẩm và thực hiện các công việc sau:
//        Liệt kê tất cả các hãng sản phẩm (Sử dụng Set)
//        Liệt kê Danh mục sản phẩm(Category) và số lượng sản phẩm thuộc danh mục đó (Map)
// Lưu ý: Category là một mảng String

public class Main {
    public static void main(String[] args) {
        ProductService service = new ProductService();
        List<Product> productList = service.getAllProducts();

        System.out.println("\nLiệt kê các sản phẩm theo id:");
        productList.forEach(i -> System.out.println(i.getId() + " - " + i.getName()));

        System.out.println("\nLiệt kê các brand sản phẩm:");
        Set<String> brandSet = new HashSet<>();
        for (Product product : productList) {
            brandSet.add(product.getBrand());
        }
        System.out.println(brandSet);

        System.out.println("\nLiệt kê loại sản phẩm (category) và số lượng sản phẩm thuộc category đó:");
        service.printAllCategories(productList);
    }
}
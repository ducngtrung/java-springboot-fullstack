package com.example.userbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}

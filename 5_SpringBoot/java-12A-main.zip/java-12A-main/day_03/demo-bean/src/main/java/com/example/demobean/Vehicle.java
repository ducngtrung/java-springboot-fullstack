package com.example.demobean;

public interface Vehicle {
    void run();
}

package vn.techmaster.crud_rest.dto;

public record BookRequest(String title, String author, int year) {
  
}
